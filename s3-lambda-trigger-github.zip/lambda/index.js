exports.handler = async (event) => {
  console.log("🚀 S3 Trigger Event Received:", JSON.stringify(event, null, 2));

  for (const record of event.Records) {
    const bucket = record.s3.bucket.name;
    const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));
    const size = record.s3.object.size;

    console.log(`🪣 Bucket: ${bucket}`);
    console.log(`📁 File: ${key}`);
    console.log(`📏 Size: ${size} bytes`);
  }

  return {
    statusCode: 200,
    body: JSON.stringify("✅ S3 event processed successfully!"),
  };
};
